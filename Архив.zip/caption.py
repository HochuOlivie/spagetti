from create_bot import _


input_token = _('⚿ Ввести API Token')
run_without_token = _('➡️ Продолжить без API')

my_account = _('🧰 Мой Аккаунт')
instructions = _('ℹ️ Инструкции')
notifications = _('💡 Уведомления')
contacts = _('📝 Контакты')
auth = _('🔑 Авторизация')

balance = _('Баланс')
news = _('Новости')
stats = _('Статистика')
offers = _('TOP офферов')
streams = _('Потоки')
payouts = _('Выплаты')
logout = _('Выход из аккаунта')
# personal_offers = 'Подборка офферов'
# withdrawal = 'Вывод средств'

RUB = _('RUB')
USD = _('USD')

notify_news = _('Новости')
notify_tickets = _('Оповещение о тикетах')
notify_payouts = _('О выплатах')
notify_leads = _('Оповещение о новых лидах')

russian = '🇷🇺 Русский'
english = '🇺🇸 English'